#include <iostream>

using namespace std;

int main()
{
    cout << "1\n2  4\n3  6  9\n4  8  12\n5  10 15 20" << endl;
    return 0;
}
