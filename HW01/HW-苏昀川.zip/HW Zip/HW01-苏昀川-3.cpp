#include <iostream>

using namespace std;

int main()
{
    cout << "  R\n RSR\nRSSSR\n RSR\n  R" << endl;
    return 0;
}
