#include<iostream>
using namespace std ;


int main()
{
    char a, b, c ;
    cout << "Input" ;
    cin.get(a) ;
    cin.get(b) ;
    cin.get(c) ;
    cout << "Premiere:"<< a << '\n'<< "Deuxieme:"<< b << '\n'<< "Troisieme:"<< c ;
}
