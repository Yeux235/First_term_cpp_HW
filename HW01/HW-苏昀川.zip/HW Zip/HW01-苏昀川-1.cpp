#include <iostream>
using namespace std ;


int main()
{
    cout << " Gongxin2525 \n 525031910697 \n Su Yunchuan \n 15204622687 \n Dongchuan Rd. 800" << endl ;
    return 0 ;
}
