#include <iostream>

using namespace std;
#define MAX_SIZE 10

int main(){
    int m, n,mat[MAX_SIZE][MAX_SIZE] ;
    bool found = false ;
    cout << "Please input m, n:" ;
    cin >> m >> n ;
    cout << "Please input array:" ;
    for (int i = 0; i < m; i++){
        for (int k = 0; k < n; k++)
            cin >> mat[i][k] ;
    }


    for (int i=0; i < m; i++){
        int row_max = mat[i][0], col_min ;
            //=====������i�����ֵ=====
        for (int k = 1; k < n; k++){
            if (mat[i][k] >= row_max) row_max = mat[i][k] ;
        }
            //=====Ȼ�����i�����Ԫ����=====
        for (int k = 0; k < n; k++){
            if (mat[i][k] == row_max){
            //===��ʼ�����Ԫ�������е���Сֵ===
                col_min = mat[0][k] ;
                for (int j = 1; j < m; j++){
                    if ( mat[j][k] < col_min ) col_min = mat[j][k] ;
                }

            //===�ҳ�����Сֵ��ȷ���Ƿ�Ϊ����===
                for (int j = 0; j < m; j++){
                    if (mat[j][k] == col_min){
                        if ( i == j ){
                            cout << "mat[" << i << "][" << k << "]=" << col_min << endl ;
                            found = true ;      //��bool flag�ж�����Ƿ�ִ�й�
                        }
                    }
                }
            }
        }
    }
    if ( !found   cout << "not found" ;
    return 0 ;
}
